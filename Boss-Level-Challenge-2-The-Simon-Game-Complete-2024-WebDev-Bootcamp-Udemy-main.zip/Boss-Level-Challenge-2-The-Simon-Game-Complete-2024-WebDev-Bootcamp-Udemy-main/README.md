# Boss-Level-Challenge-2-The-Simon-Game-Complete-2024-WebDev-Bootcamp
The Simon Game from Dr. Angela Yu's the Complete 2024 Web Development Bootcamp at Udemy
