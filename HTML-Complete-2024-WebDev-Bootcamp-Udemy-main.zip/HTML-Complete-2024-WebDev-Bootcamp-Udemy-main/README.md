# HTML-Complete-20224-WebDev-Bootcamp-2024
This repository includes coding exercises and solutions for challenges from HTML sections (01-05) from Dr. Angela Yu's Complete 2024 Web Development Bootcamp on Udemy. Perfect for learners looking to practice HTML. No prerequisites needed. Feel free to explore, modify, learn &amp; reference!
